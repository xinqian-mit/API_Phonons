# -*- coding: utf-8 -*-
"""
Created on Sun Jan  4 14:49:54 2026

@author: QGD
"""

import numpy as np
import matplotlib.pyplot as plt
root = './'

B = np.loadtxt(root + 'Ballistic.txt', comments='%', encoding='utf-8')
H = np.loadtxt(root + 'Hydrodynamic.txt', comments='%', encoding='utf-8')
D = np.loadtxt(root + 'Diffusive.txt', comments='%', encoding='utf-8')

vmax_B, vmax_H, vmax_D = 1e-5, 3e-8, 1e-10
idx_B, idx_H, idx_D = 37, 32, 10

#%%
from matplotlib.tri import Triangulation
from matplotlib import colors
from scipy.interpolate import griddata
from scipy.ndimage import gaussian_filter
from matplotlib.patches import FancyArrowPatch

bwr = plt.get_cmap('bwr')
rgb = bwr(np.linspace(0, 1, 256))[:, :3]
dark = (np.sin(np.linspace(0, np.pi, 256)) + 0.5)/1.5
cmap = colors.ListedColormap(rgb*dark[:, None])

def smooth_plot(ax, x_surf, y_surf, c_surf, vmin):
    x0, x1 = x_surf.min(), x_surf.max()
    y0, y1 = y_surf.min(), y_surf.max()
    Xi = np.linspace(x0, x1, 3000)
    Yi = np.linspace(y0, y1, 1000)
    Xi, Yi = np.meshgrid(Xi, Yi)
    Vi = griddata((x_surf, y_surf), c_surf, (Xi, Yi),
                  method='cubic')
    Vi = gaussian_filter(Vi, sigma=0.1)
    surf = ax.pcolormesh(Xi, Yi, Vi, cmap=cmap, vmin=vmin, vmax=1)
    return surf

def plot_field(ax, val, vmax, idx=12, negative=True, smooth=False):
    x_surf, y_surf = val.T[:2]
    c_surf = val.T[2 + idx]/vmax
    c_surf[x_surf > x_surf.max()/11*8.5] = 0.
    vmin = -1 if negative else 0
    if smooth:
        smooth_plot(ax, x_surf, y_surf, c_surf, vmin)
    else:
        tri = Triangulation(x_surf, y_surf)
        ax.tripcolor(tri, c_surf, cmap=cmap,
                     vmin=vmin, vmax=1)
    L = np.mean(np.abs([x_surf.max(), x_surf.min()]))
    H = np.mean(np.abs([y_surf.max(), y_surf.min()]))
    ax.set_xlim(-0.8*L, 0.9*L)
    ax.set_ylim(-0.7*H, 0.7*H)
    ax.set_aspect('equal')
    ax.axis('off')

    bar, tick_len = L/11, 0.05*H
    x0, y0 = 0.8*L, -0.6*H
    ax.plot([x0, x0 - bar], [y0, y0], 'k', lw=1)
    ax.plot([x0, x0], [y0, y0 + tick_len], 'k', lw=1)
    ax.plot([x0 - bar, x0 - bar], [y0, y0 + tick_len], 'k', lw=1)
    text = f'{bar/1e3:.1f} μm' if bar < 1e3 else f'{bar/1e3:.0f} μm'
    ax.text(x0 - bar/2, y0 - tick_len, text,
            ha='center', va='top')
    return

def plot_line(ax, H, t_d=40, h0=0.1):
    phi = np.arcsin(2.88/t_d)
    xs = np.array([H[:, 0].max(), -H[:, 0].max()])
    ys = np.array([0, 2*H[:, 0].max()*np.tan(phi)]) + H[:, 1].max()*h0
    si = lambda x: (ys[1] - ys[0])/(xs[1] - xs[0])*(x - xs[0]) + ys[0]
    i = xs*0.5 + xs.max()*0.2; j = si(i)
    ax.plot(i, j, 'k--')
    ax.plot(i, -j, 'k--')
    return phi, si

def plot_arrow(ax, H, phi, si, l0=0.1):
    l, q1_0 = l0*H.max(), 0.2*H[:, 0].max()
    q1 = [q1_0, si(q1_0)]
    q2 = [q1[0] + l*np.sin(phi), q1[1] + l*np.cos(phi)]
    arrowstyle = '-|>, head_length=4, head_width=1.5'
    q3, q4 = [q1[0], -q1[1]], [q2[0], -q2[1]]
    arrow1 = FancyArrowPatch(q1, q2, lw=1.5, color='k',
                             arrowstyle=arrowstyle)
    arrow2 = FancyArrowPatch(q3, q4, lw=1.5, color='k',
                             arrowstyle=arrowstyle)
    ax.add_patch(arrow1)
    ax.add_patch(arrow2)
    return

#%%
from numpy.fft import fft, fftshift, fftfreq
EP = [0.02, 0.43]

def gen_shape(n_src, dx, sx, n_block=1, Nx=4096, dim=1):
    A = 1.0/np.sqrt(2*np.pi)/sx
    n = np.round((n_src + 0.5)/2).astype(int)
    L = dx*(2*n + n_block)
    ps = dx*(np.arange(-n, n + 1))
    x = np.linspace(-L/2, L/2, Nx)
    kx = 2*np.pi*fftshift(fftfreq(Nx, d=L/Nx))
    f = np.zeros_like(x)
    for p in ps:
        f += A*np.exp(-((x - p)/sx)**2/2)
    F = np.abs(fftshift(fft(f)))*L/Nx
    return x, f, kx, F, ps
    
def plot_shape(ax, x, f, ps):
    ax.plot(x, f, 'b')
    ax.plot(ps, np.zeros_like(ps), 'go', ms=5)
    ax.set_xlabel('$x$ (μm)')
    ax.set_ylabel('Gaussian')
    ax.set_ylim(0, f.max()*1.1)
    ax.set_xlim(x.min(), x.max())
    return

def plot_FT(ax, k, F, log):
    ax.plot(k/2/np.pi, F, 'C0')
    ax.axvline(EP[0], c='C1', ls='--')
    ax.axvline(EP[1], c='C1', ls='--')
    ax.set_ylabel('Fourier intensity')
    ax.set_xlim(1e-3, 2e1)
    ax.set_xscale('log')
    if log:
        ax.set_ylim(1e-3, 30)
        ax.set_yscale('log')
    else:
        ax.set_ylim(0, 15)
    return

def plot_ft(ax, dx, log=False):
    n_src = 11
    sx = dx/20
    x, f, k, F, ps = gen_shape(n_src, dx, sx, dim=1)
    plot_FT(ax, k, F, log)
    s = f'{dx:.0f} μm' if dx > 1 else f'{dx:.1f} μm'
    ax.text(0.96, 0.96, s, transform=ax.transAxes,
            ha='right', va='top')
    return

#%%
from matplotlib.collections import LineCollection

def plot_hatch(ax, x1, x2, y1, y2, N=50, dx=None):
    xy = np.linspace(x1, x2, N)
    if dx is None:
        dx = (x2 - x1)/(N - 1)*0.6
    lines = np.empty((N, 2, 2))
    lines[:, 0, 1] = y1
    lines[:, 1, 1] = y2
    lines[:, 0, 0] = xy
    lines[:, 1, 0] = xy + dx
    Lines = LineCollection(lines, colors='k', lw=0.5)
    ax.add_collection(Lines)
    return

def single_arrow(ax, q1, q2, arr='->', lw=1, l=5, w=2, c='k'):
    arrowstyle = f'{arr}, head_length={l}, head_width={w}'
    arrow = FancyArrowPatch(q1, q2, lw=lw, color=c,
                            arrowstyle=arrowstyle)
    ax.add_patch(arrow)
    return

def plot_sub(ax, N=4, n=1, d=1, s=0.15, A=1):
    L = (2*N + n)*d
    ps = np.linspace(-N*d, N*d, 2*N + 1)
    x = np.linspace(-L/2, L/2, 500)
    f = np.zeros_like(x)
    for p in ps:
        f += A*np.exp(-((x - p)/s)**2/2)

    ax.set_xlim(-L/2, L/2)
    ax.set_ylim(-A*2, A*5)
    ax.axis('off')

    ax.plot(ps, np.zeros_like(ps), 'ro', ms=3, zorder=4)
    ax.axhline(0, c='k', ls=':', lw=1)
    ax.plot(x, f, c='orange', lw=1.5, label=r'$T (x,y,t)$')

    for p in ps:
        single_arrow(ax, [p, A*3], [p, A*1.2], c='r')
    single_arrow(ax, [-L/3, A*3.7], [L/3, A*3.7],
                 arr='-|>', c='C0', lw=2, l=10, w=2)
    single_arrow(ax, [ps[-2], A*2.4], [ps[-1], A*2.4],
                 arr='-|>')

    ax.text(0, A*4, '$t$', c='C0', fontsize=15,
            va='bottom', ha='center')
    ax.text((ps[-2] + ps[-1])/2, A*2.5, r'$\Delta t$',
            c='k', va='bottom', ha='center')
    plot_hatch(ax, -L/2, L/2, -A*0.3, 0)

    ax.plot([ps[-2], ps[-2]], [-A*1.25, A*1.2], ls='--', c='gray', lw=1)
    ax.plot([ps[-1], ps[-1]], [-A*1.25, A*1.2], ls='--', c='gray', lw=1)
    single_arrow(ax, [ps[-2], -A], [ps[-1], -A], arr='<->')
    ax.text((ps[-2] + ps[-1])/2, -A*1.2, r'$d$',
            c='k', va='top', ha='center')
    return

#%%
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
norm = Normalize(vmin=-1, vmax=1)
sm = ScalarMappable(cmap=cmap, norm=norm)
sm.set_array([])

fig = plt.figure(figsize=(8, 6), dpi=600)
ax1 = fig.add_axes([0.06, 0.8, 0.8, 0.18])
ax4 = fig.add_axes([0.06, 0.55, 0.2, 0.22])
ax3 = fig.add_axes([0.06, 0.3, 0.2, 0.22])
ax2 = fig.add_axes([0.06, 0.05, 0.2, 0.22])
ax7 = fig.add_axes([0.26, 0.55, 0.68, 0.22])
ax6 = fig.add_axes([0.26, 0.3, 0.68, 0.22])
ax5 = fig.add_axes([0.26, 0.05, 0.68, 0.22])

def twin_tick(ax):
    ax_ = ax.twiny()
    ax_.set_xlim(1e-3, 2e1)
    ax_.set_xscale('log')
    ax.tick_params(axis='x', labelbottom=False)
    ax_.set_xticks(EP, ['$k_{EP1}$', '$k_{EP2}$'])

plot_sub(ax1)
plot_ft(ax2, 5e2/1e3)
ax2.set_xlabel('$k_x/2\pi$ (μm$^{-1}$)')

plot_ft(ax3, 1e4/1e3)
ax3.tick_params(axis='x', labelbottom=False)

plot_ft(ax4, 5e5/1e3)
twin_tick(ax4)

for ax in [ax2, ax3, ax4]:
    ax.set_zorder(4)

ti = (np.arange(0, 750, 12.5)[idx_B] - 12.5*2)/1e3
plot_field(ax5, B, vmax_B, idx=idx_B)
ax5.text(0.5, 0, 'Weak ballistic', transform=ax5.transAxes,
         ha='center', va='bottom')
ax5.text(0.95, 0.95, f'$t=${ti:.3f} ns', transform=ax5.transAxes,
         ha='right', va='top')

ti = (np.arange(2000, 15000, 250)[idx_H] - 250*5)/1e3
plot_field(ax6, H, vmax_H, idx=idx_H, smooth=True)
phi, si = plot_line(ax6, H, t_d=20, h0=0.01)
plot_arrow(ax6, H, phi, si)
ax6.text(0.5, -0.1, 'Hydrodynamic', transform=ax6.transAxes,
         ha='center', va='bottom')
ax6.text(0.95, 0.95, f'$t=${ti:.2f} ns', transform=ax6.transAxes,
         ha='right', va='top')

ti = (np.arange(0, 3.75e5, 2.5e4)[idx_D] - 2.5e4*2)/1e3
plot_field(ax7, D, vmax_D, idx=idx_D)
ax7.text(0.5, -0.1, 'Diffusive', transform=ax7.transAxes,
         ha='center', va='bottom')
ax7.text(0.95, 0.95, f'$t=${ti:.0f} ns', transform=ax7.transAxes,
         ha='right', va='top')

cbar = plt.colorbar(sm, ax=[ax5, ax6, ax7], location='right',
                    shrink=0.95, aspect=50, pad=0)
cbar.set_label(r'$\theta$', rotation=0)

fig.text(-0.01, 1 - 0.01, '(a)', transform=fig.transFigure,
         va='top', ha='left', fontsize=12)
for i, si in zip([0, 0.3], ['bdf', 'ceg']):
    for j, s in zip([0.8, 0.55, 0.3], si):
        fig.text(i - 0.01, j - 0.01, f'({s})',
                 transform=fig.transFigure,
                 va='top', ha='left', fontsize=12)

plt.savefig(root + 'fig.png', bbox_inches='tight')

